layoutit
========
LayoutIt官网已推出简体中文，可直接访问 http://layoutit.com/cn   
LayoutIt的创作者暂时不希望项目开源，但保持layoutit.com的官网工具提供免费服务，
为了尊重源作者的知识产权和支持小团队的生存发展，已将开源代码清除，并将代码改进意见提交给源作者，
如果你觉得layoutit的项目值得赞，可通过官网的donate支持一下。  

To the requirements of the project founders, they don't want their code be open source for business reason, but will keep this tool free. 
In order to respect the founders intellectual property rights and support small teams of survival and development, I will clean the github source and submit the improvements to them. 
If you appreciate this tool, donation is recommended for offical website.
