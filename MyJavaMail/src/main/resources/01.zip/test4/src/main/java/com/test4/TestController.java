package com.test4;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
@Scope("prototype")
@Controller
@Transactional(rollbackFor=Exception.class)
@RequestMapping(value = "/test")
public class TestController {
	@Autowired JdbcTemplate jdbcTemplate;
	@RequestMapping("/test1")
	public String forAdd(HttpServletRequest request) throws Exception{
		List<Map<String, Object>> list = jdbcTemplate.queryForList("select * from test");
		request.setAttribute("list", list);
		return "/test1";
	}
}