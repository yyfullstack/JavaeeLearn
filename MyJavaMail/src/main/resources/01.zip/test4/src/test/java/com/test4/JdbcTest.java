package com.test4;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class JdbcTest {
	public static void main(String[] args) throws Exception {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(new String[] { "applicationContext.xml" });
		System.out.println(context);
		System.in.read(); // 防止系统退出
	}
}